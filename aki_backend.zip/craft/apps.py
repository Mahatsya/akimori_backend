from django.apps import AppConfig


class CraftConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "craft"
    verbose_name = "Крафт / шапки материалов"
