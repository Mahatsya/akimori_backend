from django.apps import AppConfig

class CustomItemConfig(AppConfig):
    name = "customitem"
    verbose_name = "Custom Items"
