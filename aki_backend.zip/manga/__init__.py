default_app_config = "manga.apps.MangaConfig"
