from __future__ import annotations

from rest_framework import serializers
from django.utils import timezone

from .models import PromoCode


class PromoCodeInSerializer(serializers.Serializer):
    code = serializers.CharField(max_length=32)

    def validate_code(self, value: str) -> str:
        return value.strip().upper()


class PromoTopupQuoteInSerializer(PromoCodeInSerializer):
    amount_minor = serializers.IntegerField(min_value=1)
    currency = serializers.CharField(max_length=3, required=False, allow_blank=True)

    def validate_currency(self, value: str) -> str:
        return (value or "").strip().upper()


class PromoTopupApplyInSerializer(PromoTopupQuoteInSerializer):
    # опционально, если у тебя будет topup_id / payment_id — добавишь сюда
    pass


class PromoRedeemInSerializer(PromoCodeInSerializer):
    # если бонус считается от суммы пополнения (PERCENT) — можно передать сумму
    topup_amount_minor = serializers.IntegerField(min_value=1, required=False, allow_null=True)


class PromoEffectOutSerializer(serializers.Serializer):
    type = serializers.CharField()
    data = serializers.DictField()


class PromoOutSerializer(serializers.Serializer):
    code = serializers.CharField()
    is_active = serializers.BooleanField()
    starts_at = serializers.DateTimeField()
    ends_at = serializers.DateTimeField()
    max_total_uses = serializers.IntegerField()
    max_uses_per_user = serializers.IntegerField()
    uses_count = serializers.IntegerField()
    effect = PromoEffectOutSerializer()


def build_effect_payload(promo: PromoCode, *, topup_amount_minor: int | None = None) -> dict:
    """
    Единый формат эффекта для фронта.
    """
    if hasattr(promo, "topup_discount"):
        eff = promo.topup_discount
        return {
            "type": "topup_discount",
            "data": {
                "currency": eff.currency,
                "discount_type": eff.discount_type,
                "discount_value": str(eff.discount_value),
                "min_topup_minor": eff.min_topup_minor,
                "max_discount_minor": eff.max_discount_minor,
            },
        }

    if hasattr(promo, "balance_bonus"):
        eff = promo.balance_bonus
        data = {
            "currency": eff.currency,
            "bonus_type": eff.bonus_type,
            "bonus_value": str(eff.bonus_value),
            "min_topup_minor": eff.min_topup_minor,
        }
        # если percent — можно сразу посчитать “сколько бонуса”
        if eff.bonus_type == eff.BonusType.PERCENT and topup_amount_minor is not None:
            try:
                data["bonus_minor_preview"] = eff.calc_bonus_minor(topup_amount_minor=topup_amount_minor)
            except Exception:
                pass
        return {"type": "balance_bonus", "data": data}

    if hasattr(promo, "item_grant"):
        eff = promo.item_grant
        return {
            "type": "item_grant",
            "data": {"item_id": eff.item_id},
        }

    return {"type": "none", "data": {}}
