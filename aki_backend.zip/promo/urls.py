from django.urls import path

from .views import (
    PromoValidateView,
    PromoRedeemView,
    PromoTopupQuoteView,
    PromoTopupApplyView,
)

urlpatterns = [
    path("promo/validate/", PromoValidateView.as_view(), name="promo-validate"),
    path("promo/redeem/", PromoRedeemView.as_view(), name="promo-redeem"),

    path("promo/topup/quote/", PromoTopupQuoteView.as_view(), name="promo-topup-quote"),
    path("promo/topup/apply/", PromoTopupApplyView.as_view(), name="promo-topup-apply"),
]
