from __future__ import annotations

from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.db.models import F
from django.utils import timezone

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import PromoCode, PromoRedemption
from .serializers import (
    PromoCodeInSerializer,
    PromoTopupQuoteInSerializer,
    PromoTopupApplyInSerializer,
    PromoRedeemInSerializer,
    PromoOutSerializer,
    build_effect_payload,
)


def api_error(code: str, http_status=status.HTTP_400_BAD_REQUEST):
    return Response({"detail": code}, status=http_status)


def get_promo_or_404(code: str):
    try:
        return PromoCode.objects.get(code=code)
    except PromoCode.DoesNotExist:
        return None


def promo_to_out(promo: PromoCode, *, topup_amount_minor: int | None = None) -> dict:
    return {
        "code": promo.code,
        "is_active": promo.is_active,
        "starts_at": promo.starts_at,
        "ends_at": promo.ends_at,
        "max_total_uses": promo.max_total_uses,
        "max_uses_per_user": promo.max_uses_per_user,
        "uses_count": promo.uses_count,
        "effect": build_effect_payload(promo, topup_amount_minor=topup_amount_minor),
    }


class PromoValidateView(APIView):
    """
    Проверка промокода для текущего пользователя:
    - активен ли
    - в окне ли времени
    - не превышены ли лимиты
    - не использовал ли пользователь ранее
    Возвращает промо + описание эффекта.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        s = PromoCodeInSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        code = s.validated_data["code"]

        promo = get_promo_or_404(code)
        if promo is None:
            return api_error("promo_not_found", status.HTTP_404_NOT_FOUND)

        ok, reason = promo.can_user_redeem(request.user)
        if not ok:
            return api_error(reason)

        data = promo_to_out(promo)
        return Response(PromoOutSerializer(data).data, status=status.HTTP_200_OK)


class PromoRedeemView(APIView):
    """
    Обычное применение (не пополнение):
    - BALANCE_BONUS: начисляет сразу (как у тебя в PromoCode.apply_effect)
    - ITEM_GRANT: выдаёт сразу
    - TOPUP_DISCOUNT: запрещаем здесь (нужно /topup/apply)
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        s = PromoRedeemInSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        code = s.validated_data["code"]
        topup_amount_minor = s.validated_data.get("topup_amount_minor")

        promo = get_promo_or_404(code)
        if promo is None:
            return api_error("promo_not_found", status.HTTP_404_NOT_FOUND)

        if hasattr(promo, "topup_discount"):
            return api_error("topup_discount_use_topup_apply", status.HTTP_400_BAD_REQUEST)

        ip = request.META.get("REMOTE_ADDR", "")
        ua = request.META.get("HTTP_USER_AGENT", "")

        try:
            redemption = promo.redeem(
                request.user,
                context="manual",
                topup_amount_minor=topup_amount_minor,
                ip=ip,
                ua=ua,
            )
        except DjangoValidationError as e:
            # {"code": ["reason"]} или {"code": "reason"}
            msg = e.message_dict.get("code")
            if isinstance(msg, list) and msg:
                return api_error(msg[0])
            if isinstance(msg, str):
                return api_error(msg)
            return api_error("invalid_promo")

        return Response(
            {
                "ok": True,
                "redeemed_at": redemption.redeemed_at,
                "payload": redemption.payload,
            },
            status=status.HTTP_201_CREATED,
        )


class PromoTopupQuoteView(APIView):
    """
    Рассчитать скидку/бонус для пополнения (НЕ тратит промокод).
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        s = PromoTopupQuoteInSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        code = s.validated_data["code"]
        amount_minor = s.validated_data["amount_minor"]

        promo = get_promo_or_404(code)
        if promo is None:
            return api_error("promo_not_found", status.HTTP_404_NOT_FOUND)

        ok, reason = promo.can_user_redeem(request.user)
        if not ok:
            return api_error(reason)

        # TOPUP_DISCOUNT
        if hasattr(promo, "topup_discount"):
            eff = promo.topup_discount
            q = eff.quote(amount_minor)
            if not q.get("ok"):
                return api_error(q.get("reason", "invalid_topup_amount"))
            return Response(
                {
                    "promo": promo_to_out(promo, topup_amount_minor=amount_minor),
                    "quote": q,
                },
                status=status.HTTP_200_OK,
            )

        # BALANCE_BONUS (preview)
        if hasattr(promo, "balance_bonus"):
            eff = promo.balance_bonus
            try:
                bonus_minor = eff.calc_bonus_minor(topup_amount_minor=amount_minor)
            except DjangoValidationError as e:
                msg = e.message_dict.get("code")
                if isinstance(msg, list) and msg:
                    return api_error(msg[0])
                if isinstance(msg, str):
                    return api_error(msg)
                return api_error("invalid_bonus")
            return Response(
                {
                    "promo": promo_to_out(promo, topup_amount_minor=amount_minor),
                    "quote": {"ok": True, "bonus_minor": bonus_minor},
                },
                status=status.HTTP_200_OK,
            )

        # ITEM_GRANT не зависит от суммы пополнения
        if hasattr(promo, "item_grant"):
            return Response(
                {
                    "promo": promo_to_out(promo),
                    "quote": {"ok": True},
                },
                status=status.HTTP_200_OK,
            )

        return api_error("promo_has_no_effect")


class PromoTopupApplyView(APIView):
    """
    Зафиксировать применение промокода для пополнения (ТРАХАЕТ лимиты и создаёт redemption).
    Возвращает данные для создания платежа/пополнения:

    - TOPUP_DISCOUNT -> {payable_minor, discount_minor}
    - BALANCE_BONUS  -> {bonus_minor} (начислять ПОСЛЕ успешной оплаты в твоём topup-flow)
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        s = PromoTopupApplyInSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        code = s.validated_data["code"]
        amount_minor = s.validated_data["amount_minor"]

        promo = get_promo_or_404(code)
        if promo is None:
            return api_error("promo_not_found", status.HTTP_404_NOT_FOUND)

        ip = request.META.get("REMOTE_ADDR", "")
        ua = request.META.get("HTTP_USER_AGENT", "")

        # Всё делаем в транзакции, чтобы не было гонок по лимитам
        try:
            with transaction.atomic():
                locked = PromoCode.objects.select_for_update().get(pk=promo.pk)

                ok, reason = locked.can_user_redeem(request.user)
                if not ok:
                    raise DjangoValidationError({"code": reason})

                # TOPUP_DISCOUNT
                if hasattr(locked, "topup_discount"):
                    eff = locked.topup_discount
                    q = eff.quote(amount_minor)
                    if not q.get("ok"):
                        raise DjangoValidationError({"code": q.get("reason", "invalid_topup_amount")})

                    redemption = PromoRedemption.objects.create(
                        promo=locked,
                        user=request.user,
                        redeemed_at=timezone.now(),
                        context="topup",
                        topup_amount_minor=amount_minor,
                        ip=ip,
                        user_agent=ua,
                        payload={
                            "type": "topup_discount",
                            "currency": eff.currency,
                            "amount_minor": amount_minor,
                            "discount_minor": q["discount_minor"],
                            "payable_minor": q["payable_minor"],
                        },
                    )

                    PromoCode.objects.filter(pk=locked.pk).update(uses_count=F("uses_count") + 1)

                    return Response(
                        {
                            "ok": True,
                            "redeemed_at": redemption.redeemed_at,
                            "payload": redemption.payload,
                        },
                        status=status.HTTP_201_CREATED,
                    )

                # BALANCE_BONUS — фиксируем и возвращаем сколько начислить ПОСЛЕ оплаты
                if hasattr(locked, "balance_bonus"):
                    eff = locked.balance_bonus
                    bonus_minor = eff.calc_bonus_minor(topup_amount_minor=amount_minor)
                    if bonus_minor <= 0:
                        raise DjangoValidationError({"code": "bonus_is_zero"})

                    redemption = PromoRedemption.objects.create(
                        promo=locked,
                        user=request.user,
                        redeemed_at=timezone.now(),
                        context="topup",
                        topup_amount_minor=amount_minor,
                        ip=ip,
                        user_agent=ua,
                        payload={
                            "type": "balance_bonus_pending",
                            "currency": eff.currency,
                            "topup_amount_minor": amount_minor,
                            "bonus_minor": bonus_minor,
                        },
                    )

                    PromoCode.objects.filter(pk=locked.pk).update(uses_count=F("uses_count") + 1)

                    return Response(
                        {
                            "ok": True,
                            "redeemed_at": redemption.redeemed_at,
                            "payload": redemption.payload,
                            "note": "Начисли bonus_minor после успешной оплаты пополнения",
                        },
                        status=status.HTTP_201_CREATED,
                    )

                # ITEM_GRANT для пополнения не нужен — но если вызвали сюда, можно разрешить как “manual”
                if hasattr(locked, "item_grant"):
                    raise DjangoValidationError({"code": "item_grant_use_redeem"})

                raise DjangoValidationError({"code": "promo_has_no_effect"})

        except DjangoValidationError as e:
            msg = e.message_dict.get("code")
            if isinstance(msg, list) and msg:
                return api_error(msg[0])
            if isinstance(msg, str):
                return api_error(msg)
            return api_error("invalid_promo")
