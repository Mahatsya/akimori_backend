from django.contrib import admin
from django.utils import timezone

from .models import (
    PromoCode,
    PromoRedemption,
    PromoTopupDiscount,
    PromoBalanceBonus,
    PromoItemGrant,
)


class PromoTopupDiscountInline(admin.StackedInline):
    model = PromoTopupDiscount
    extra = 0
    can_delete = True


class PromoBalanceBonusInline(admin.StackedInline):
    model = PromoBalanceBonus
    extra = 0
    can_delete = True


class PromoItemGrantInline(admin.StackedInline):
    model = PromoItemGrant
    extra = 0
    can_delete = True


@admin.register(PromoCode)
class PromoCodeAdmin(admin.ModelAdmin):
    list_display = (
        "code",
        "is_active",
        "starts_at",
        "ends_at",
        "uses_count",
        "max_total_uses",
        "max_uses_per_user",
    )
    list_filter = ("is_active", "starts_at", "ends_at")
    search_fields = ("code",)
    ordering = ("-created_at",)

    readonly_fields = ("uses_count", "created_at")
    fieldsets = (
        (None, {"fields": ("code", "is_active", "note")}),
        ("Validity window", {"fields": ("starts_at", "ends_at")}),
        ("Limits", {"fields": ("max_total_uses", "max_uses_per_user", "uses_count")}),
        ("Meta", {"fields": ("created_at",)}),
    )

    inlines = [
        PromoTopupDiscountInline,
        PromoBalanceBonusInline,
        PromoItemGrantInline,
    ]

    actions = ("make_active_today_to_tomorrow", "deactivate_promos")

    @admin.action(description="Активировать: окно сегодня → завтра (24 часа)")
    def make_active_today_to_tomorrow(self, request, queryset):
        now = timezone.now()
        queryset.update(
            is_active=True,
            starts_at=now,
            ends_at=now + timezone.timedelta(days=1),
        )

    @admin.action(description="Отключить промокоды (is_active=False)")
    def deactivate_promos(self, request, queryset):
        queryset.update(is_active=False)


@admin.register(PromoRedemption)
class PromoRedemptionAdmin(admin.ModelAdmin):
    list_display = ("promo", "user", "redeemed_at", "context", "topup_amount_minor", "ip")
    list_filter = ("context", "redeemed_at")
    search_fields = ("promo__code", "user__username", "user__email")
    readonly_fields = ("promo", "user", "redeemed_at", "context", "topup_amount_minor", "ip", "user_agent", "payload")
    ordering = ("-redeemed_at",)


@admin.register(PromoTopupDiscount)
class PromoTopupDiscountAdmin(admin.ModelAdmin):
    list_display = ("promo", "currency", "discount_type", "discount_value", "min_topup_minor", "max_discount_minor")
    list_filter = ("currency", "discount_type")
    search_fields = ("promo__code",)
    autocomplete_fields = ("promo",)


@admin.register(PromoBalanceBonus)
class PromoBalanceBonusAdmin(admin.ModelAdmin):
    list_display = ("promo", "currency", "bonus_type", "bonus_value", "min_topup_minor")
    list_filter = ("currency", "bonus_type")
    search_fields = ("promo__code",)
    autocomplete_fields = ("promo",)


@admin.register(PromoItemGrant)
class PromoItemGrantAdmin(admin.ModelAdmin):
    list_display = ("promo", "item")
    search_fields = ("promo__code", "item__title", "item__name")
    autocomplete_fields = ("promo", "item")
